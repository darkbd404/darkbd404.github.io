package com.darkbd.ytadskipper

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.media.AudioManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AdSkipperAccessibilityService : AccessibilityService() {

    private var isMutedByService = false

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val rootNode = rootInActiveWindow ?: return

        // 1. Search by Skip Button View IDs (Fastest)
        val skipButtonIds = listOf(
            "com.google.android.youtube:id/skip_ad_button",
            "com.google.android.youtube:id/modern_skip_ad_button"
        )
        var adSkipped = false
        for (id in skipButtonIds) {
            val nodes = rootNode.findAccessibilityNodeInfosByViewId(id)
            if (!nodes.isNullOrEmpty()) {
                for (node in nodes) {
                    if (performClickOnNode(node)) {
                        adSkipped = true
                        break
                    }
                }
            }
            if (adSkipped) break
        }

        // 2. Fallback: Search by text keywords
        if (!adSkipped) {
            val skipKeywords = listOf("Skip", "Skip Ad", "Skip Ads", "স্কিপ করুন", "বিজ্ঞাপন এড়িয়ে যান")
            for (keyword in skipKeywords) {
                val nodes = rootNode.findAccessibilityNodeInfosByText(keyword)
                if (!nodes.isNullOrEmpty()) {
                    for (node in nodes) {
                        if (performClickOnNode(node)) {
                            adSkipped = true
                            break
                        }
                    }
                }
                if (adSkipped) break
            }
        }

        // 3. Auto-Mute during unskippable ads
        val adBadgeNodes = rootNode.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/ad_badge")
        val adCountdownNodes = rootNode.findAccessibilityNodeInfosByViewId("com.google.android.youtube:id/ad_countdown")
        val isAdPlaying = !adBadgeNodes.isNullOrEmpty() || !adCountdownNodes.isNullOrEmpty()

        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (isAdPlaying && !isMutedByService) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
            isMutedByService = true
        } else if (!isAdPlaying && isMutedByService) {
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            isMutedByService = false
        }
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo?): Boolean {
        var currentNode = node
        while (currentNode != null) {
            if (currentNode.isClickable) {
                return currentNode.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            currentNode = currentNode.parent
        }
        return false
    }

    override fun onInterrupt() {
        if (isMutedByService) {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            isMutedByService = false
        }
    }
}
