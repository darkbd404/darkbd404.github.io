package com.darkbd.ytadskipper

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(60, 80, 60, 60)
            setBackgroundColor(Color.parseColor("#121212"))
        }

        val titleText = TextView(this).apply {
            text = "YT Super Ad Skipper ⚡"
            textSize = 24f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 15)
        }

        val subText = TextView(this).apply {
            text = "নিচের ধাপগুলো অনুসরণ করুন এবং সরাসরি আপনার ফোনের YouTube অ্যাপ রান করুন:"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, 40)
        }

        val btnPermission = Button(this).apply {
            text = "১. Accessibility পারমিশন অন করুন"
            setBackgroundColor(Color.parseColor("#2962FF"))
            setTextColor(Color.WHITE)
            setPadding(40, 30, 40, 30)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                Toast.makeText(
                    context,
                    "Installed Apps থেকে 'YT Super Ad Skipper' অন করুন",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        val spacer = TextView(this).apply { height = 30 }

        val btnStartAndLaunchYT = Button(this).apply {
            text = "২. নোটিফিকেশন চালু করে YouTube রান করুন"
            setBackgroundColor(Color.parseColor("#D50000"))
            setTextColor(Color.WHITE)
            setPadding(40, 30, 40, 30)
            setOnClickListener {
                val serviceIntent = Intent(this@MainActivity, ForegroundStatusService::class.java)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }

                // Multiple YouTube package fallback checks (Official, Vanced, ReVanced)
                val ytPackages = listOf(
                    "com.google.android.youtube",
                    "app.revanced.android.youtube",
                    "com.vanced.android.youtube"
                )
                
                var launched = false
                for pkg in ytPackages {
                    val ytIntent = packageManager.getLaunchIntentForPackage(pkg)
                    if (ytIntent != null) {
                        startActivity(ytIntent)
                        launched = true
                        break
                    }
                }

                if (!launched) {
                    // Fallback intent by action/category if direct launch package fails
                    try {
                        val webIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com"))
                        startActivity(webIntent)
                        launched = true
                    } catch (e: Exception) {
                        // ignore
                    }
                }

                if (!launched) {
                    Toast.makeText(context, "ফোনে YouTube অ্যাপ খুঁজে পাওয়া যায়নি!", Toast.LENGTH_LONG).show()
                }
            }
        }

        layout.addView(titleText)
        layout.addView(subText)
        layout.addView(btnPermission)
        layout.addView(spacer)
        layout.addView(btnStartAndLaunchYT)

        setContentView(layout)
    }
}
