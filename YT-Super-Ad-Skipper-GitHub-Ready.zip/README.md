# YT Super Ad Skipper ⚡

GitHub Actions ব্যবহার করে সরাসরি এই প্রোজেক্ট থেকে Android APK বিল্ড করার নিয়ম:

1. GitHub-এ একটি নতুন Repository তৈরি করুন।
2. এই ZIP ফাইলের ভেতরের সব ফাইল ও ফোল্ডার (`.github` ফোল্ডারসহ) ওই Repository-তে আপলোড করুন।
3. আপলোড শেষ হলে আপনার Repository-এর **Actions** ট্যাবে যান।
4. সেখানে **Build Android APK** নামের ওয়ার্কফ্লো অটোমেটিক চলতে শুরু করবে (না চললে Run workflow বাটনে ক্লিক করুন)।
5. বিল্ড সম্পন্ন হলে (সবুজ টিক চিহ্ন এলে) সেটিতে ক্লিক করে নিচে **Artifacts** সেকশন থেকে `YT-Super-Ad-Skipper-APK` ডাউনলোড করে ফোনে ইনস্টল করুন।
